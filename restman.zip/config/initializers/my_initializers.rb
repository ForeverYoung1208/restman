# don't forget to set system environment variable
# export RESTMAN_PROTOCOL=HTTPS
# if you are using https protocol


# System constants

::SUPERUSERS = ['ForeverYoung','admin']  
::ADMIN_ROLE_ID = 1
::USER_ROLE_ID = 2
