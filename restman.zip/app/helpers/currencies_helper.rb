module CurrenciesHelper
end
