module AccTypesHelper
end
