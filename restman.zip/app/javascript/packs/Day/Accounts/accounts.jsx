import React from "react"
import PropTypes from "prop-types"

export class AccountSaldoOn extends React.Component{
	constructor(props){
		super(props)
	}



	render(){
		return(
			<div>{res}</div>
		)
	}

}
// AccountSaldoOn.propTypes = {
// 	date: PropTypes.date.isRequired
// 	company:
// 	currency: 

// }