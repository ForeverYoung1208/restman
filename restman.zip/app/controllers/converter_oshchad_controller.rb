class ConverterOshchadController < ApplicationController
	def converter

		
	end
end
