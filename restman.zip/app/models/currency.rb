class Currency < ApplicationRecord
end
