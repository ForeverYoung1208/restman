class AccType < ApplicationRecord
end
