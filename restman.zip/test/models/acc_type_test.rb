require 'test_helper'

class AccTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
